import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import datasets
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
import pickle

df=pd.read_csv('Training.csv')
df1=pd.read_csv('Testing.csv')

X_train=df.iloc[:,0:132]
y_train=df.iloc[:,132]
X_test=df1.iloc[:,0:132]
y_test=df1.iloc[:,132]

# disease_name={'(vertigo) Paroymsal  Positional Vertigo':1, 'AIDS':2, 'Acne':3, 'Alcoholic hepatitis':4, 'Allergy':5, 'Arthritis':6, 'Bronchial Asthma':7, 'Cervical spondylosis':8, 'Chicken pox':9, 'Chronic cholestasis':10, 'Common Cold':11, 'Dengue':12, 'Diabetes ':13, 'Dimorphic hemmorhoids(piles)':14, 'Drug Reaction':15, 'Fungal infection':16, 'GERD':17, 'Gastroenteritis':18, 'Heart attack':19, 'Hepatitis B':20, 'Hepatitis C':21, 'Hepatitis D':22, 'Hepatitis E':23, 'Hypertension ':24, 'Hyperthyroidism':25, 'Hypoglycemia':26, 'Hypothyroidism':27, 'Impetigo':28, 'Jaundice':29, 'Malaria':30, 'Migraine':31, 'Osteoarthristis':32, 'Paralysis (brain hemorrhage)':33, 'Peptic ulcer diseae':34, 'Pneumonia':35, 'Psoriasis':36, 'Tuberculosis':37, 'Typhoid':38, 'Urinary tract infection':39, 'Varicose veins':40, 'hepatitis A':41}

# y=y.map(disease_name)
# y1=y1.map(disease_name)

gnb = GaussianNB()
gnb.fit(X_train, y_train)
gnb_pred = gnb.predict(X_test)

pickle.dump(gnb, open("model.pkl", "wb"))
